self.addEventListener("install", () => {
  console.log("Service worker installed");

  caches.open("login").then((cache) => {
    cache.add("./index.html");
    cache.add("./manifest.json");
  });
});

self.addEventListener("activate", () => {
  console.log("Service worker activated");
});

const fetchUserDetails = async () => {
  const data = await fetch("https://api.github.com/users/i-punithgowda");
  return data.json();
};

self.addEventListener("fetch", async (event) => {
  console.log(await fetchUserDetails());

  self.addEventListener("fetch", (e) => {
    e.respondWith(
      (async () => {
        const r = await caches.match(e.request);
        console.log(`[Service Worker] Fetching resource: ${e.request.url}`);
        if (r) {
          return r;
        }
        const response = await fetch(
          "https://api.github.com/users/i-punithgowda"
        );
        const cache = await caches.open("login");
        console.log(`[Service Worker] Caching new resource: ${e.request.url}`);
        cache.put(e.request, response.json());
        return response;
      })()
    );
  });
});
